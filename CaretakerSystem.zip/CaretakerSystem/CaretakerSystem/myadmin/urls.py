from django.urls import path
from . import views

urlpatterns = [
    path('index/', views.Dasboard),
    path('', views.LoginPage),
    path('logout/', views.logout_call),
    path('create-staff/', views.UserCreatePage),
    path('edit-user/<int:id>/<int:empid>/<int:eadid>/<int:regid>/<int:bkid>/', views.UserInfo, name="staff_updt"),
    # path('delete-staff/<int:id>/<int:empid>/<int:eadid>/<int:regid>/<int:bkid>/', views.StaffDelete, name="staff_del"),
    path('staff-table/', views.StaffTable, name="all-staff"),
    path('capacity/', views.Capacity),
    path('regular-visits/', views.RegularVisits),
    path('plan-rounds/', views.Rounds),
]
